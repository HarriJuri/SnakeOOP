﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SnakeOOP
{
    enum Direction
    {
        LEFT,
        RIGHT,
        UP,
        DOWN
    }
}
